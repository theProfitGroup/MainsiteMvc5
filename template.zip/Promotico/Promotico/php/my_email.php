<?php
// Replace my_mail@my_domain.com with your E-mail address(es)...

// This is email address on which you will receive
// your subscribers email addresses via SUBSCRIBE FORM on Home page:

$subscribe_email = "my_mail@my_domain.com";


// This is email address on which you will receive
// messages via CONTACT FORM on your website:

$contact_email = "my_mail@my_domain.com";


// If you want to receive subscribers and messages on the same Email address, you guess,
// type the same Email address for both variables :)
?>